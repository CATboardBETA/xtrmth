| **XTRMTH**
|
| All your math one single library. No more need to fill dependencies.
| **Just. Math.**
| 
| The days of an import for every function and variable are finally over.
| **Two imports.**
| 
| Beyond the limits of `math` in some spots, in version 1.2.
| 
| 
| {{documentation to be added in version 2.0.0, along with the inclusion of xm variables (xmv.py)}}
| 
| See you on the other side.