# XTRMTH

All your math.
#### **One Library.**
All you functions.
#### **One Import.**

## The days of endlessly searching through documentation are over.
XTRMTH uses easy-to-understand syntax, and won't force memorization of every edge-case. 

## No more strange, inadequate errors.
All edge-cases* have a detailed, concice, error message. More broad errors will use formatted strings to show exactly where and how you messed up.

{Documentation to be added in version 2.0.0, along with xtrmth variables (xmv.py).}

*\*personally found or reported*
