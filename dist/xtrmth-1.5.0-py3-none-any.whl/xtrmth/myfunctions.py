def _TEST_IMPORT(printing: bool):
    if printing is True:
        print("XTRMTH:XTRMTH:connected:True")
        return True
    else:
        return True
